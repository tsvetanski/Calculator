﻿namespace WpfCalculator.Common
{
    public static class FunctionConstants
    {
        public const string ClearAll = "C";
        public const string SingleDel = "Del";
        public const string ChangeSign = "ChangeSign";
        public const string Separator = "Dec";
    }
}
