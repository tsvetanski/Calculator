﻿namespace WpfCalculator.Common
{
    public class MessageConstants
    {
        public const string Undefined = "Undefined";
        public const string InvalidOperation = "Invalid Operation";
    }
}
