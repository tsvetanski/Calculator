﻿namespace WpfCalculator.Common
{
    public class OperationConstants
    {
        public const string Add = "+";
        public const string Substract = "-";
        public const string Multiply = "*";
        public const string Divide = "/";
    }
}
